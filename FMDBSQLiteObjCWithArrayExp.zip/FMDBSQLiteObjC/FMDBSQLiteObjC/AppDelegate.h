//
//  AppDelegate.h
//  FMDBSQLiteObjC
//
//  Created by cricket21 on 22/09/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Com.h"
#import "FMDatabase.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
- (void)createPath;


@end

