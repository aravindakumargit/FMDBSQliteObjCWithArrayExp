//
//  Com.h
//  FMDBSQLiteObjC
//
//  Created by cricket21 on 22/09/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Com : NSObject
+(void)dbpath:(NSString *)path;
+(NSString*)dbpath;
@end
