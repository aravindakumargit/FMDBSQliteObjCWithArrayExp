//
//  Com.m
//  FMDBSQLiteObjC
//
//  Created by cricket21 on 22/09/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "Com.h"

@implementation Com
static NSString *_dbpath;

+(void)dbpath:(NSString *)path{
    _dbpath = path;
    
}
+(NSString*)dbpath{
    return _dbpath;
    
}
@end
