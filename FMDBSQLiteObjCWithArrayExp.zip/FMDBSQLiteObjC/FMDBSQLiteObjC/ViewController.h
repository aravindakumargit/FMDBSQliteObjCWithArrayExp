//
//  ViewController.h
//  FMDBSQLiteObjC
//
//  Created by cricket21 on 22/09/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"
#import "Com.h"
@interface ViewController : UIViewController
- (IBAction)CreateStadiam:(id)sender;
- (IBAction)showData:(id)sender;


@end

