//
//  ViewController.m
//  FMDBSQLiteObjC
//
//  Created by cricket21 on 22/09/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self createLogInTable];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createLogInTable{
    if (![[NSFileManager defaultManager] fileExistsAtPath:[Com dbpath]])
    {
        FMDatabase *database =[FMDatabase databaseWithPath:[Com dbpath]];
        [database open];
        [database beginTransaction];
        BOOL res = TRUE;
        //1st profile
        res = res && [database executeUpdate:@"CREATE TABLE IF NOT EXISTS tbl_login (first_name VARCHAR, last_name VARCHAR,email VARCHAR, phone VARCHAR)"];
        if(res){
            [database commit];
            NSLog(@"Table is created successfully");
        }
        else{
            [database rollback];
            NSLog(@"something went wrong");
        }
        [database close];
    }
}
-(void)createStadiamTable{
        FMDatabase *database =[FMDatabase databaseWithPath:[Com dbpath]];
        [database open];
        [database beginTransaction];
        BOOL res = TRUE;
        //1st profile
        res = res && [database executeUpdate:@"CREATE TABLE IF NOT EXISTS stadium (ID INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR,Country VARCHAR, City VARCHAR UNIQUE)"];
        // to avoid duplication  u can add unique
        if(res){
            NSLog(@"Table is created successfully");
            [database commit];
        }
        else{
            NSLog(@"something went wrong");
            [database rollback];
        }
        [database close];
        NSMutableArray *StadiumName=[[NSMutableArray alloc]init];
    [StadiumName addObject:@"Turf CityA"];
    [StadiumName addObject:@"Cage Sport Park"];
    [StadiumName addObject:@"Dempsey Ground"];
    [StadiumName addObject:@"NTU"];
    [StadiumName addObject:@"Sports Ground"];
    [StadiumName addObject:@"Sports Ground1"];    
   database =[FMDatabase databaseWithPath:[Com dbpath]];
    [database open];
    for (int i=0; i<[StadiumName count]; i++) {
        [database executeUpdate:@"insert into stadium (Name,Country,City) values(?,?,?)",[StadiumName objectAtIndex:i],@"singapore",[StadiumName objectAtIndex:i]];
    }
    [database close];
}
- (IBAction)CreateStadiam:(id)sender {
    [self createStadiamTable];
}

- (IBAction)showData:(id)sender {
    NSMutableArray *results = [NSMutableArray array];
    FMDatabase *database =[FMDatabase databaseWithPath:[Com dbpath]];
    [database open];
    FMResultSet *resprof = [database executeQuery:@"SELECT * FROM stadium"];
    NSLog(@"the result set %@",resprof);
    while ([resprof next]) {
        NSLog(@"data is %@",[resprof resultDictionary]);
        [results addObject:[resprof objectForKeyedSubscript:@"Name"]];
    }
    NSLog(@"the result is %@",results);
    [database close];
}
@end
